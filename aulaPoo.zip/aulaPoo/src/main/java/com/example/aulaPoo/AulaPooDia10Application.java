package com.example.aulaPoo;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class AulaPooDia10Application {

	public static void main(String[] args) {
		SpringApplication.run(AulaPooDia10Application.class, args);
	}

}
